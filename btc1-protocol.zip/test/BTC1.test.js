const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("BTC1 Stablecoin", function () {
  let BTC1, btc1, owner, addr1;

  beforeEach(async function () {
    BTC1 = await ethers.getContractFactory("BTC1");
    [owner, addr1] = await ethers.getSigners();
    btc1 = await BTC1.deploy();
    await btc1.deployed();
  });

  it("Should mint BTC1 tokens", async function () {
    await btc1.mint(1);
    const balance = await btc1.balanceOf(owner.address);
    expect(balance).to.be.gt(0);
  });

  it("Should burn BTC1 tokens on redeem", async function () {
    await btc1.mint(1);
    const balanceBefore = await btc1.balanceOf(owner.address);
    await btc1.redeem(balanceBefore);
    const balanceAfter = await btc1.balanceOf(owner.address);
    expect(balanceAfter).to.equal(0);
  });
});