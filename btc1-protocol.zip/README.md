# BTC1 Protocol

Bitcoin-backed self-stabilizing stablecoin (BTC1).  
Features:
- Dollar-pegged using BTC collateral
- Arbitrage-ready hooks for peg stabilization
- Transparent on-chain proof-of-reserves (future)
- Multi-chain ready

## Setup
1. Install dependencies: `npm install`
2. Compile contracts: `npx hardhat compile`
3. Run tests: `npx hardhat test`
4. Deploy to local or testnet: `npx hardhat run scripts/deploy.js --network <network-name>`