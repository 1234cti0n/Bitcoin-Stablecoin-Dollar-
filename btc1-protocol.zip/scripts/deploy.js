async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with account:", deployer.address);

    const BTC1 = await ethers.getContractFactory("BTC1");
    const btc1 = await BTC1.deploy();

    await btc1.deployed();
    console.log("BTC1 deployed to:", btc1.address);
}

main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });